from .inference import VitInference

__all__ = [
    'VitInference'
]
