import torch.nn as nn

from easy_ViTPose.vit_models.backbone.vit import ViT
from easy_ViTPose.vit_models.head.topdown_heatmap_simple_head import TopdownHeatmapSimpleHead


__all__ = ['ViTPose']


class ViTPose(nn.Module):
    def __init__(self, cfg: dict):
        super(ViTPose, self).__init__()
        backbone_cfg = {k: v for k, v in cfg['backbone'].items() if k != 'type'}  # 配置
        head_cfg = {k: v for k, v in cfg['keypoint_head'].items() if k != 'type'}  # 配置

        self.backbone = ViT(**backbone_cfg)  # 编码器
        self.keypoint_head = TopdownHeatmapSimpleHead(**head_cfg)  # 解码器

    def forward(self, image, fmap):
        # 提取编码器输出
        output_bone, hmap = self.backbone(image, feature=fmap)
        # 将变换后的特征传入解码器
        output = self.keypoint_head(output_bone)

        return output
