import os
from tqdm import tqdm
import cv2
import numpy as np
import shutil
# from model import *
from configs.ViTPose_base_coco_256x192 import model as model_cfg
# from dataset.loader import PairLoader
from vit_utils.top_down_eval import keypoints_from_heatmaps
from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn as nn
from vit_models.backbone.vit import ViT
from vit_models.head.topdown_heatmap_simple_head import TopdownHeatmapSimpleHead

class ViTPose(nn.Module):
    def __init__(self, cfg: dict):
        super(ViTPose, self).__init__()
        backbone_cfg = {k: v for k, v in cfg['backbone'].items() if k != 'type'}  # 配置
        head_cfg = {k: v for k, v in cfg['keypoint_head'].items() if k != 'type'}  # 配置

        self.backbone = ViT(**backbone_cfg)  # 编码器
        self.keypoint_head = TopdownHeatmapSimpleHead(**head_cfg)  # 解码器

    def forward(self, image, fmap):
        # 提取编码器输出
        output_bone, hmap = self.backbone(image, feature=fmap)
        # 将变换后的特征传入解码器
        output = self.keypoint_head(output_bone)

        return output

pose_network = ViTPose(model_cfg)
# "D:\our_project\package\vitpose-25-b.pth"
ckpt = torch.load(r"D:\cvpr_model\(cvpr)fine_epoch_15_pose.pth", map_location='cpu')
if 'state_dict' in ckpt:
    pose_network.load_state_dict(ckpt['state_dict'])
else:
    pose_network.load_state_dict(ckpt)

pose_network = pose_network.cpu()
pose_network.eval()
# print(pose_network)


import torch.nn as nn
import torch.nn.functional as F

# 注意力模块
class AttentionBlock(nn.Module):
    def __init__(self, in_channels, gating_channels, inter_channels=None):
        super(AttentionBlock, self).__init__()

        if inter_channels is None:
            inter_channels = in_channels // 2

        self.W_x = nn.Conv2d(in_channels, inter_channels, kernel_size=1)
        self.W_g = nn.Conv2d(gating_channels, inter_channels, kernel_size=1)
        self.psi = nn.Conv2d(inter_channels, 1, kernel_size=1)

    def forward(self, x, g):
        x1 = self.W_x(x)
        g1 = F.interpolate(self.W_g(g), size=x.size()[2:], mode='bilinear', align_corners=True)
        psi = F.relu(x1 + g1, inplace=True)
        psi = self.psi(psi)
        psi = torch.sigmoid(psi)
        return x * psi

    # U-net 注意力模块
class AttentionUNetBlock(nn.Module):
    def __init__(self, in_channels, out_channels, channel=64, kernel_size=3):
        super(AttentionUNetBlock, self).__init__()

        # Encoder
        self.conv1 = nn.Conv2d(in_channels, channel, kernel_size, padding=1)
        self.conv2 = nn.Conv2d(channel, channel * 2, kernel_size, stride=2, padding=1)
        self.conv3 = nn.Conv2d(channel * 2, channel * 2, kernel_size, padding=1)
        # Attention Block
        self.attention = AttentionBlock(channel * 2, channel * 2)

        # Decoder
        self.conv4 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv5 = nn.Conv2d(channel * 3, channel, kernel_size, padding=1)
        self.conv6 = nn.Conv2d(channel, out_channels, kernel_size, padding=1)

    # AttentionUNetBlock 的 forward 方法
    def forward(self, x):
        # Encoder
        x1 = F.relu(self.conv1(x))
        x2 = F.relu(self.conv2(x1))
        x3 = F.relu(self.conv3(x2))

        # Attention Mechanism
        x = self.attention(x2, x3)

        # Decoder
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)  # 使用双线性插值进行上采样
        x = F.relu(self.conv4(x))

        x2 = F.interpolate(x2, scale_factor=2, mode='bilinear', align_corners=True)  # 使用双线性插值进行上采样

        x = torch.cat((x, x2), dim=1)

        x = F.relu(self.conv5(x))
        x = self.conv6(x)

        return x

class DecomNet(nn.Module):

    def __init__(self, channel=64, kernel_size=3, is_Training=True):
        super(DecomNet, self).__init__()

        # self.conv0 = nn.Conv2d(4, channel // 2, kernel_size, padding=1)
        self.conv = nn.Conv2d(4, channel, kernel_size * 3, padding=4)
        self.conv1 = nn.Conv2d(channel, channel, kernel_size, padding=1)
        self.conv2 = nn.Conv2d(channel, channel * 2, kernel_size, stride=2, padding=1)
        self.conv3 = nn.Conv2d(channel * 2, channel * 2, kernel_size, padding=1)
        # Attention U-Net Blocks
        self.attention_unet1 = AttentionUNetBlock(channel, channel)
        self.attention_unet2 = AttentionUNetBlock(channel * 2, channel * 2)
        self.attention_unet3 = AttentionUNetBlock(channel * 2, channel * 2)

        self.conv4 = nn.Conv2d(channel * 4, channel, kernel_size, stride=2, padding=1)
        self.conv5 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv6 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv7 = nn.Conv2d(channel, 4, kernel_size, padding=1)

    def forward(self, x):
        feature = []
        x_hist = torch.max(x, dim=1, keepdim=True)
        x = torch.cat((x, x_hist[0]), dim=1)
        # 改变x1
        x = self.conv(x)
        x1 = x
        x1 = self.attention_unet1(x1)
        # 改变x2
        x = F.relu(self.conv1(x))
        x2 = x
        # 改变x3
        x = F.relu(self.conv2(x))
        x3 = x
        x3 = self.attention_unet3(x3)

        x = F.relu(self.conv3(x))
        x = torch.cat((x, x3), dim=1)
        x = F.relu(self.conv4(x))
        x = F.interpolate(x, size=(x2.size()[2], x2.size()[3]), mode='bilinear', align_corners=True)
        x = torch.cat((x, x2), dim=1)
        x = F.relu(self.conv5(x))
        x = torch.cat((x, x1), dim=1)

        x = self.conv6(x)
        feature = x
        out = self.conv7(x)

        return out, feature

lowlight_network = DecomNet().float()
lowlight_network.load_state_dict(torch.load(r"D:\论文的各种杂东西\lowlight_enhance_final_model\model_89.pt"))
lowlight_network = lowlight_network.cpu()
lowlight_network.eval()

from vit_utils.top_down_eval import keypoints_from_heatmaps
from torchvision import transforms
import time

start_time = time.time()  # 记录开始时间


def calculate_mean_std(image_path):
    # 读取图像
    img = cv2.imread(image_path)

    # 将图像从BGR转换为RGB（OpenCV默认读取为BGR格式）
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # 计算每个通道的均值和方差
    mean = np.mean(img_rgb, axis=(0, 1)) / 255  # 每个通道的均值，并归一化
    std = np.std(img_rgb, axis=(0, 1)) / 255  # 每个通道的标准差，并归一化

    return mean, std


def postprocess(heatmaps, org_w, org_h):
    heatmaps_cpu = heatmaps.cpu().detach().numpy()  # 将张量移动到主机内存
    points, prob = keypoints_from_heatmaps(heatmaps=heatmaps_cpu,
                                           center=np.array([[org_w // 2, org_h // 2]]),
                                           scale=np.array([[org_w, org_h]]),
                                           unbiased=True, use_udp=True)
    return np.concatenate([points[:, :, ::-1], prob], axis=2)


# 替换为你要评估的图像的路径|
image_path = r"D:\pic\331.jpg"
# "D:\low_light_model_back\eval15\low\55.jpg"
# "D:\easy_ViTPose-main\easy_ViTPose\datasets\COCO\train2017\000000000036.jpg"

img = cv2.imread(image_path)

img1 = transforms.ToTensor()(img)
resize_transform = transforms.Resize((400, 712))
img1 = resize_transform(img1)

img1 = img1.unsqueeze(0)
print(img1.shape)
output, feature = lowlight_network(img1)

Mean, Std = calculate_mean_std(image_path)

# Mean=[0.485, 0.456, 0.406]
# Std=[0.229, 0.224, 0.225]

target_size = (192, 256)


def pre_img(img):
    org_h, org_w = img.shape[:2]
    img_input = cv2.resize(img, target_size, interpolation=cv2.INTER_LINEAR) / 255
    img_input = ((img_input - Mean) / Std).transpose(2, 0, 1)[None]
    return img_input, org_h, org_w


def _inference_torch(img: np.ndarray, feature) -> np.ndarray:
    img_input, org_h, org_w = pre_img(img)
    img_input_tensor = torch.from_numpy(img_input).float()
    org_h_tensor = torch.tensor(org_h)
    org_w_tensor = torch.tensor(org_w)

    outputs = pose_network(img_input_tensor, fmap=feature)

    if isinstance(outputs, tuple):
        outputs = outputs[0]

    selected_indices = [0, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 22]

    outputs = outputs[:, selected_indices, :, :]
    heatmaps = outputs.detach().cpu()
    org_w_tensor = org_w_tensor.cpu()
    org_h_tensor = org_h_tensor.cpu()

    return postprocess(heatmaps, org_w_tensor, org_h_tensor)


output = _inference_torch(img, feature=feature)
print(output.shape)
modified_array = {}

sublists = []
for sublist in output[0]:
    modified_sublist = []
    for i, item in enumerate(sublist):
        if i < 2:
            modified_sublist.append(item)
        else:
            modified_sublist.append(item)
    sublists.append(modified_sublist)

print(sublists)

sublists = [sublists]


import numpy as np
from PIL import Image
from vit_utils.visualization import joints_dict,draw_points_and_skeleton
import matplotlib.pyplot as plt
import os
from typing import List, Tuple
import numpy as np
import cv2


image = np.array(Image.open(image_path), dtype=np.uint8)[:, :, ::-1]  # 将图片转换为RGB格式

# 设置保存目录
save_dir = "D:\pic"
os.makedirs(save_dir, exist_ok=True)  # 确保保存目录存在

# 遍历每个姿态信息
for idx, sublists in enumerate(sublists):
    # 使用 sublists 中的姿态信息
    my = np.array([sublists])

    # 在图像上绘制骨架
    img_with_skeleton = draw_points_and_skeleton(image.copy(), my[0],
                                    joints_dict()['my']['skeleton'],
                                    person_index=0,
                                    points_color_palette='gist_rainbow',
                                    skeleton_color_palette='Grays',
                                    points_palette_samples=10,
                                    confidence_threshold=0)

    # 显示图像
    plt.imshow(img_with_skeleton)
    plt.axis('off')
    plt.show()

    # 生成文件名
    prefix = "combine"
    filename = f"{prefix}_{23}.png"
    file_path = os.path.join(save_dir, filename)

    # 保存图像
    Image.fromarray(img_with_skeleton).save(file_path)

    print(f"图像 {filename} 已保存到 {save_dir}")
