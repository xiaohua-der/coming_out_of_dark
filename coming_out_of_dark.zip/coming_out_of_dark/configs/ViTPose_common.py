# Common configuration
optimizer = dict(type='AdamW', lr=1e-3, betas=(0.9, 0.999), weight_decay=0.1,
                 constructor='LayerDecayOptimizerConstructor', 
                 paramwise_cfg=dict(
                                    num_layers=12, 
                                    layer_decay_rate=1 - 2e-4,
                                    custom_keys={
                                            'bias': dict(decay_multi=0.),
                                            'pos_embed': dict(decay_mult=0.),
                                            'relative_position_bias_table': dict(decay_mult=0.),
                                            'norm': dict(decay_mult=0.)
                                            }
                                    )
                )
# AdamW 优化器  主要是用在反向传播上的
# 学习率为0.001

# 梯度剪裁的设置，使用 L2 形式剪裁，最大范数为 1
optimizer_config = dict(grad_clip=dict(max_norm=1., norm_type=2))

# learning policy  学习率配置 再去看看学习率那一章节的教程
lr_config = dict(
    policy='step',    # step的策略
    warmup='linear',  #
    warmup_iters=300,
    warmup_ratio=0.001,
    step=[3])

total_epochs = 4
target_type = 'GaussianHeatmap'
# 25改成了17，两个都变了
# 这些也得注意修改  # , 17, 18, 19, 20, 21, 22, 23, 24 dataset_channel和inference_channel都一样
channel_cfg = dict(
    num_output_channels=25,  #
    dataset_joints=25,
    dataset_channel=[[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                      16, 17, 18, 19, 20, 21, 22, 23, 24], ],
    inference_channel=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                       16, 17, 18, 19, 20, 21, 22, 23, 24])

data_cfg = dict(   # 调整数据集的配置
    image_size=[192, 256],
    heatmap_size=[48, 64],
    num_output_channels=channel_cfg['num_output_channels'],
    num_joints=channel_cfg['dataset_joints'],
    dataset_channel=channel_cfg['dataset_channel'],
    inference_channel=channel_cfg['inference_channel'],
    soft_nms=False,
    nms_thr=1.0,
    oks_thr=0.9,
    vis_thr=0.2,
    use_gt_bbox=False,
    det_bbox_thr=0.0,
    bbox_file='data/coco/person_detection_results/'
    'COCO_val2017_detections_AP_H_56_person.json',
)

data_root = 'D:\easy_ViTPose-main\easy_ViTPose\datasets\COCO'
data = dict(
    samples_per_gpu=1,  # 这个修改batch_size
    workers_per_gpu=6,
    val_dataloader=dict(samples_per_gpu=128),
    test_dataloader=dict(samples_per_gpu=128),
    train=dict(
        type='TopDownCocoDataset',
        ann_file=f'{data_root}/annotations/person_keypoints_train2017.json',
        img_prefix=f'{data_root}/train2017/',
        data_cfg=data_cfg),
    val=dict(
        type='TopDownCocoDataset',
        ann_file=f'{data_root}/annotations/person_keypoints_val2017.json',
        img_prefix=f'{data_root}/val2017/',
        data_cfg=data_cfg),
    test=dict(
        type='TopDownCocoDataset',
        ann_file=f'{data_root}/annotations/person_keypoints_val2017.json',
        img_prefix=f'{data_root}/val2017/',
        data_cfg=data_cfg)
)
