import torch

# import numpy as np

# check if CUDA is available

train_on_gpu = torch.cuda.is_available()

if not train_on_gpu:
    print('CUDA is not available.  Training on CPU ...')
else:
    print('CUDA is available!  Training on GPU ...')
    device = torch.device("cuda:1")  # Use GPU 1
    torch.cuda.set_device(device)  # Set the current device to GPU 1

import torch.optim as optim
# from model import *
from torchvision import datasets
import torchvision.transforms as transforms
from torchvision.datasets.folder import default_loader
from torch.utils.data.sampler import SubsetRandomSampler

from torchvision.datasets.folder import default_loader


def load_dataset():
    data_path = r"/mnt/data2/temp2/pycharm_project_887/our485/"
    extensions = ['.png']  # 指定图片扩展名，可以根据实际情况调整
    train_dataset = datasets.DatasetFolder(
        root=data_path,
        loader=default_loader,
        extensions=extensions,
        transform=transforms.ToTensor()
    )
    # 6效果不够好
    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=4,
        num_workers=2,
        shuffle=True
    )
    return train_loader


import torch.nn as nn
import torch.nn.functional as F
import cv2
import numpy as np
from torchvision import transforms


# 注意力模块
class AttentionBlock(nn.Module):
    def __init__(self, in_channels, gating_channels, inter_channels=None):
        super(AttentionBlock, self).__init__()

        if inter_channels is None:
            inter_channels = in_channels // 2

        self.W_x = nn.Conv2d(in_channels, inter_channels, kernel_size=1)
        self.W_g = nn.Conv2d(gating_channels, inter_channels, kernel_size=1)
        self.psi = nn.Conv2d(inter_channels, 1, kernel_size=1)

    def forward(self, x, g):
        x1 = self.W_x(x)
        g1 = F.interpolate(self.W_g(g), size=x.size()[2:], mode='bilinear', align_corners=True)
        psi = F.relu(x1 + g1, inplace=True)
        psi = self.psi(psi)
        psi = torch.sigmoid(psi)
        return x * psi


# U-net 注意力模块
class AttentionUNetBlock(nn.Module):
    def __init__(self, in_channels, out_channels, channel=64, kernel_size=3):
        super(AttentionUNetBlock, self).__init__()

        # Encoder
        self.conv1 = nn.Conv2d(in_channels, channel, kernel_size, padding=1)
        self.conv2 = nn.Conv2d(channel, channel * 2, kernel_size, stride=2, padding=1)
        self.conv3 = nn.Conv2d(channel * 2, channel * 2, kernel_size, padding=1)
        # Attention Block
        self.attention = AttentionBlock(channel * 2, channel * 2)

        # Decoder
        self.conv4 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv5 = nn.Conv2d(channel * 3, channel, kernel_size, padding=1)
        self.conv6 = nn.Conv2d(channel, out_channels, kernel_size, padding=1)

    # AttentionUNetBlock 的 forward 方法
    def forward(self, x):
        # Encoder
        x1 = F.relu(self.conv1(x))
        x2 = F.relu(self.conv2(x1))
        x3 = F.relu(self.conv3(x2))

        # Attention Mechanism
        x = self.attention(x2, x3)

        # Decoder
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)  # 使用双线性插值进行上采样
        x = F.relu(self.conv4(x))

        x2 = F.interpolate(x2, scale_factor=2, mode='bilinear', align_corners=True)  # 使用双线性插值进行上采样

        x = torch.cat((x, x2), dim=1)

        x = F.relu(self.conv5(x))
        x = self.conv6(x)

        return x


import torch.nn as nn
import torch.nn.functional as F
import cv2
import numpy as np
from torchvision import transforms


class DecomNet(nn.Module):

    def __init__(self, channel=64, kernel_size=3, is_Training=True):
        super(DecomNet, self).__init__()

        # self.conv0 = nn.Conv2d(4, channel // 2, kernel_size, padding=1)
        self.conv = nn.Conv2d(4, channel, kernel_size * 3, padding=4)
        self.conv1 = nn.Conv2d(channel, channel, kernel_size, padding=1)
        self.conv2 = nn.Conv2d(channel, channel * 2, kernel_size, stride=2, padding=1)
        self.conv3 = nn.Conv2d(channel * 2, channel * 2, kernel_size, padding=1)
        # Attention U-Net Blocks
        self.attention_unet1 = AttentionUNetBlock(channel, channel)
        self.attention_unet2 = AttentionUNetBlock(channel * 2, channel * 2)
        self.attention_unet3 = AttentionUNetBlock(channel * 2, channel * 2)

        self.conv4 = nn.Conv2d(channel * 4, channel, kernel_size, stride=2, padding=1)
        self.conv5 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv6 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv7 = nn.Conv2d(channel, 4, kernel_size, padding=1)

    def forward(self, x):
        feature = []
        x_hist = torch.max(x, dim=1, keepdim=True)
        x = torch.cat((x, x_hist[0]), dim=1)
        # 改变x1
        x = self.conv(x)
        x1 = x
        x1 = self.attention_unet1(x1)
        # 改变x2
        x = F.relu(self.conv1(x))
        x2 = x
        # 改变x3
        x = F.relu(self.conv2(x))
        x3 = x
        x3 = self.attention_unet3(x3)

        x = F.relu(self.conv3(x))
        x = torch.cat((x, x3), dim=1)
        x = F.relu(self.conv4(x))
        x = F.interpolate(x, size=(x2.size()[2], x2.size()[3]), mode='bilinear', align_corners=True)
        x = torch.cat((x, x2), dim=1)
        x = F.relu(self.conv5(x))
        x = torch.cat((x, x1), dim=1)

        x = self.conv6(x)
        feature = x
        out = self.conv7(x)

        return out, feature


def gradient_new(input_tensor, direction):
    smooth_kernel_x = torch.reshape(torch.tensor([[0, 0], [-1, 1]], dtype=torch.float32), [2, 1, 2, 1])
    smooth_kernel_y = smooth_kernel_x.permute(2, 1, 0, 3)

    if direction == "x":
        kernel = smooth_kernel_x
    elif direction == "y":
        kernel = smooth_kernel_y

    input_tensor = input_tensor.to(device)  # 将输入张量移动到指定设备

    return torch.abs(F.conv2d(input_tensor, kernel.to(device), stride=(1, 1), padding=1))


def rgb_to_grayscale(tensor):
    tensor = tensor.cpu()
    # Assuming tensor shape is [batch_size, channels, height, width]
    img = transforms.functional.to_pil_image(tensor[0], mode=None)
    img_gs = transforms.functional.to_grayscale(img, num_output_channels=1)
    return transforms.functional.to_tensor(img_gs)


# R 表示图像的反射率（reflectance）
# I 表示输入图像
# 损失的目的是鼓励学到的反射率图在空间上更加平滑。
def smooth(I, R):
    R1 = torch.squeeze(R, 0)
    R = rgb_to_grayscale(R1)
    R = R.to(device).unsqueeze(0)
    I_x = gradient_new(I, "x").to(device)
    R_x = gradient_new(R, "x").to(device)
    I_y = gradient_new(I, "y").to(device)
    R_y = gradient_new(R, "y").to(device)
    return torch.mean(I_x * torch.exp(-10 * R_x) + I_y * torch.exp(-10 * R_y))


def color_constancy_loss(R):
    # Calculate color constancy loss based on pairs of channels (R, G), (R, B), and (G, B)
    loss_col = 0.0

    # Get the average intensity values for each channel
    R_avg = torch.mean(R[:, 0, :, :])  # Average intensity value of R channel
    G_avg = torch.mean(R[:, 1, :, :])  # Average intensity value of G channel
    B_avg = torch.mean(R[:, 2, :, :])  # Average intensity value of B channel

    # Calculate the squared differences between channel pairs and accumulate the loss
    loss_col += (R_avg - G_avg) ** 2
    loss_col += (R_avg - B_avg) ** 2
    loss_col += (G_avg - B_avg) ** 2

    return loss_col


# L 表示图像的照明图（illumination）
# im_eq 是一个经过直方图均衡化处理的图像
def lowLightLoss(input_im, R, L, im_eq):
    L_3 = torch.cat((L, L, L), dim=1)
    recon_loss_low = torch.mean(torch.abs(R * L_3 - input_im))  # 公式4（重构损失）
    #  the loss of reflectance image,
    R_low_max = torch.max(R, dim=1, keepdims=True)  # R_low_max[0] 和 im_eq 的绝对差的平均值
    # recon_loss_low_eq = torch.mean(torch.abs(R_low_max[0] - im_eq))  # 公式5（需要替换）
    loss_col = color_constancy_loss(R)
    # R1 = R.detach()
    # R1 = torch.reshape(R1, (400, 600, 3))
    # R1 = R1.numpy()
    # print(R1.shape)

    R1 = R.detach().cpu()  # 将张量从计算图中分离并移回CPU
    # print(R1.shape)
    R_gray = rgb_to_grayscale(R1).to(device)  # 在转换为灰度图像后移回 GPU
    R_gray = R_gray.cpu()  # 将张量移回CPU
    a = gradient_new(R_gray, "x")
    b = gradient_new(R_gray, "y")
    a = a.cpu()  # 将梯度张量移回 CPU
    b = b.cpu()  # 将梯度张量移回 CPU
    # print(shp_a)
    # print(shp_b)

    # 通过直方图均衡化和梯度加权来调整图像的亮度
    R_low_loss_smooth = torch.mean(torch.abs(a) + torch.abs(b))  # 公式6
    Ismooth_loss_low = smooth(L, R)

    # recon_loss_low+ 0.1 * Ismooth_loss_low + 0.01 * R_low_loss_smooth  这是专注提亮，提高人物动作恢复情况
    loss_Decom_zhangyu = recon_loss_low + 0.2 * Ismooth_loss_low + 0.005 * R_low_loss_smooth + 0.2 * loss_col
    return loss_Decom_zhangyu


model = DecomNet()
model.to(device)
# print(model)

model.train()  # 准备模型进行训练

import torch

optimizer = torch.optim.Adam(model.parameters(), lr=0.0001, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.0001,
                             amsgrad=False)

n_epochs = 100  # suggest training between 20-50 epochs
import numpy as np
from PIL import Image
from pylab import *
import cv2
from PIL import ImageFilter


def histeq(im, nbr_bins=256):
    imhist, bins = histogram(im.flatten(), nbr_bins, density=True)
    cdf = imhist.cumsum()
    cdf = 1.0 * cdf / cdf[-1]
    im2 = interp(im.flatten(), bins[:-1], cdf)
    return im2.reshape(im.shape)


for epoch in range(n_epochs):
    # 监控训练损失

    train_loss = 0.0
    for batch_idx, (data, target) in enumerate(load_dataset()):
        # 清除所有优化变量的梯度
        optimizer.zero_grad()

        # 前向传播：通过将输入传递给模型来计算预测输出
        data, target = data.to(device), target.to(device)

        eq = data.clone()
        im_max_channel = torch.max(eq, dim=1, keepdim=True)
        im_max_channel = im_max_channel[0].squeeze(0)
        img = im_max_channel.detach().cpu().numpy()
        im_eq = histeq(img)
        im_eq = torch.from_numpy(im_eq).float().to(device)
        im_eq = im_eq.unsqueeze(0)

        output, feature = model(data)

        R = F.sigmoid(output[:, 0:3, :, :])
        L = F.sigmoid(output[:, 3:4, :, :])
        loss = lowLightLoss(data, R, L, im_eq)

        loss.backward()  # 反向传播：计算损失相对于模型参数的梯度
        optimizer.step()  # 执行单次优化步骤（参数更新）
        train_loss += loss.item() * data.size(0)  # 更新累计训练损失

    train_loss = train_loss / len(load_dataset())  # 计算一个 epoch 的平均损失
    print('Epoch: {} \tTraining Loss: {:.6f}'.format(epoch, train_loss))

    # 每训练十次保存一次模型
    if (epoch + 1) % 10 == 0:
        print("Saving Epoch " + str(epoch))
        path = "model_" + str(epoch) + ".pt"
        torch.save(model.state_dict(), path)
        print("Saved!")
