import os
from tqdm import tqdm
import cv2
import numpy as np
import shutil
from configs.ViTPose_base_coco_256x192 import model as model_cfg
from vit_models.model import ViTPose
# from model import *
# from dataset.loader import PairLoader
from torch.utils.data import DataLoader
from vit_utils.inference import pad_image
from vit_utils.top_down_eval import keypoints_from_heatmaps
from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.functional as F
from vit_models.backbone.vit import ViT
from vit_models.head.topdown_heatmap_simple_head import TopdownHeatmapSimpleHead

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# 定义pose的损失函数
class JointsMSELoss(nn.Module):

    def __init__(self, use_target_weight=False, loss_weight=1.):
        super().__init__()
        self.criterion = nn.MSELoss()
        self.use_target_weight = use_target_weight
        self.loss_weight = loss_weight

    def forward(self, output, target, target_weight):

        batch_size = output.size(0)  # 考虑到输出元组的第一个元素
        num_joints = output.size(1)  # 考虑到输出元组的第一个元素

        heatmaps_pred = output.reshape(
            (batch_size, num_joints, -1)).split(1, 1)
        heatmaps_gt = target.reshape((batch_size, num_joints, -1)).split(1, 1)

        loss = 0.

        for idx in range(num_joints):
            heatmap_pred = heatmaps_pred[idx].squeeze(1)
            heatmap_gt = heatmaps_gt[idx].squeeze(1)

            if self.use_target_weight:
                loss += self.criterion(heatmap_pred * target_weight[:, idx],
                                       heatmap_gt * target_weight[:, idx])
            else:
                loss += self.criterion(heatmap_pred, heatmap_gt)

        return loss / num_joints * self.loss_weight


# 我们定义的模型
class ViTPoseWithEnhancement(nn.Module):
    def __init__(self, cfg: dict):
        super(ViTPoseWithEnhancement, self).__init__()
        backbone_cfg = {k: v for k, v in cfg['backbone'].items() if k != 'type'}  # 配置
        head_cfg = {k: v for k, v in cfg['keypoint_head'].items() if k != 'type'}  # 配置

        self.backbone = ViT(**backbone_cfg)  # 编码器
        self.keypoint_head = TopdownHeatmapSimpleHead(**head_cfg)  # 解码器

    def forward(self, image, fmap):
        # 提取编码器输出
        output_bone, hmap = self.backbone(image, feature=fmap)
        # 将变换后的特征传入解码器
        output = self.keypoint_head(output_bone)

        return output


pose_network = ViTPoseWithEnhancement(model_cfg).to(device).float()
ckpt = torch.load(r"/mnt/data2/temp2/pycharm_project_887/vitpose-25-b.pth", map_location='cpu')

if 'state_dict' in ckpt:
    pose_network.load_state_dict(ckpt['state_dict'])
else:
    pose_network.load_state_dict(ckpt)

pose_criterion = JointsMSELoss()  # 这个是pose的损失函数
pose_optimizer = torch.optim.Adam(pose_network.parameters(), lr=2e-4)  # 反向传播优化器
# base条件下的vit模型的block是十二个，如果模型不对会报错
# print(pose_network)

import torch.nn as nn
import torch.nn.functional as F


# 注意力模块
class AttentionBlock(nn.Module):
    def __init__(self, in_channels, gating_channels, inter_channels=None):
        super(AttentionBlock, self).__init__()

        if inter_channels is None:
            inter_channels = in_channels // 2

        self.W_x = nn.Conv2d(in_channels, inter_channels, kernel_size=1)
        self.W_g = nn.Conv2d(gating_channels, inter_channels, kernel_size=1)
        self.psi = nn.Conv2d(inter_channels, 1, kernel_size=1)

    def forward(self, x, g):
        x1 = self.W_x(x)
        g1 = F.interpolate(self.W_g(g), size=x.size()[2:], mode='bilinear', align_corners=True)
        psi = F.relu(x1 + g1, inplace=True)
        psi = self.psi(psi)
        psi = torch.sigmoid(psi)
        return x * psi

    # U-net 注意力模块


class AttentionUNetBlock(nn.Module):
    def __init__(self, in_channels, out_channels, channel=64, kernel_size=3):
        super(AttentionUNetBlock, self).__init__()

        # Encoder
        self.conv1 = nn.Conv2d(in_channels, channel, kernel_size, padding=1)
        self.conv2 = nn.Conv2d(channel, channel * 2, kernel_size, stride=2, padding=1)
        self.conv3 = nn.Conv2d(channel * 2, channel * 2, kernel_size, padding=1)
        # Attention Block
        self.attention = AttentionBlock(channel * 2, channel * 2)

        # Decoder
        self.conv4 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv5 = nn.Conv2d(channel * 3, channel, kernel_size, padding=1)
        self.conv6 = nn.Conv2d(channel, out_channels, kernel_size, padding=1)

    # AttentionUNetBlock 的 forward 方法
    def forward(self, x):
        # Encoder
        x1 = F.relu(self.conv1(x))
        x2 = F.relu(self.conv2(x1))
        x3 = F.relu(self.conv3(x2))

        # Attention Mechanism
        x = self.attention(x2, x3)

        # Decoder
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)  # 使用双线性插值进行上采样
        x = F.relu(self.conv4(x))

        x2 = F.interpolate(x2, scale_factor=2, mode='bilinear', align_corners=True)  # 使用双线性插值进行上采样

        x = torch.cat((x, x2), dim=1)

        x = F.relu(self.conv5(x))
        x = self.conv6(x)

        return x


class DecomNet(nn.Module):

    def __init__(self, channel=64, kernel_size=3, is_Training=True):
        super(DecomNet, self).__init__()

        # self.conv0 = nn.Conv2d(4, channel // 2, kernel_size, padding=1)
        self.conv = nn.Conv2d(4, channel, kernel_size * 3, padding=4)
        self.conv1 = nn.Conv2d(channel, channel, kernel_size, padding=1)
        self.conv2 = nn.Conv2d(channel, channel * 2, kernel_size, stride=2, padding=1)
        self.conv3 = nn.Conv2d(channel * 2, channel * 2, kernel_size, padding=1)
        # Attention U-Net Blocks
        self.attention_unet1 = AttentionUNetBlock(channel, channel)
        self.attention_unet2 = AttentionUNetBlock(channel * 2, channel * 2)
        self.attention_unet3 = AttentionUNetBlock(channel * 2, channel * 2)

        self.conv4 = nn.Conv2d(channel * 4, channel, kernel_size, stride=2, padding=1)
        self.conv5 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv6 = nn.Conv2d(channel * 2, channel, kernel_size, padding=1)
        self.conv7 = nn.Conv2d(channel, 4, kernel_size, padding=1)

    def forward(self, x):
        feature = []
        x_hist = torch.max(x, dim=1, keepdim=True)
        x = torch.cat((x, x_hist[0]), dim=1)
        # 改变x1
        x = self.conv(x)
        x1 = x
        x1 = self.attention_unet1(x1)
        # 改变x2
        x = F.relu(self.conv1(x))
        x2 = x
        # 改变x3
        x = F.relu(self.conv2(x))
        x3 = x
        x3 = self.attention_unet3(x3)

        x = F.relu(self.conv3(x))
        x = torch.cat((x, x3), dim=1)
        x = F.relu(self.conv4(x))
        x = F.interpolate(x, size=(x2.size()[2], x2.size()[3]), mode='bilinear', align_corners=True)
        x = torch.cat((x, x2), dim=1)
        x = F.relu(self.conv5(x))
        x = torch.cat((x, x1), dim=1)

        x = self.conv6(x)
        feature = x
        out = self.conv7(x)

        return out, feature


lowlight_network = DecomNet().to(device).float()
lowlight_network.load_state_dict(torch.load(r"/mnt/data2/temp2/pycharm_project_887/model_79.pt"))

# print(lowlight_network)

# 实例化线性模块
pose_network.train()  # 设置为训练模式
lowlight_network.train()  # 设置为训练模式

# 先训练再冻结
pose_network.backbone._freeze_stages()  # 冻结

import os
import cv2
import json
import numpy as np
import torch

torch.manual_seed(233)
np.random.seed(233)


class CustomDataset():
    def __init__(self, data_dir, is_train=True, scale=True, scale_factor=0.35,
                 flip_prob=0, rotate_prob=0.5, rotation_factor=45., pixel_std=200, image_size=(400, 712)):
        self.data_dir = data_dir
        self.pixel_std = pixel_std
        self.image_size = image_size
        self.transform = transforms.Compose([
            transforms.ToTensor(),  #
            transforms.Normalize(mean=[0.0049, 0.0034, 0.0037], std=[0.0171, 0.0156, 0.0149]),
        ])

        self.pose_file = os.path.join(data_dir, "pose.txt")
        self.poses = self._load_poses()
        self.is_train = is_train
        self.scale = scale
        self.scale_factor = scale_factor
        self.flip_prob = flip_prob
        self.rotate_prob = rotate_prob
        self.rotation_factor = rotation_factor
        self.num_joints = 17

        self.aspect_ratio = image_size[0] * 1.0 / image_size[1]

    def _load_poses(self):
        poses = []
        with open(self.pose_file, 'r') as f:
            json_array = json.load(f)
            for json_data in json_array:
                pose = np.array(json_data['pose'], dtype=np.float32)
                poses.append(pose)
        return poses

    def __len__(self):
        return len(self.poses)

    def _box2cs(self, box):
        x, y, w, h = box[:4]
        return self._xywh2cs(x, y, w, h)

    def _xywh2cs(self, x, y, w, h):
        center = np.zeros((2,), dtype=np.float32)
        center[0] = x + w * 0.5
        center[1] = y + h * 0.5

        if w > self.aspect_ratio * h:
            h = w * 1.0 / self.aspect_ratio
        elif w < self.aspect_ratio * h:
            w = h * self.aspect_ratio
        scale = np.array(
            [w * 1.0 / self.pixel_std, h * 1.0 / self.pixel_std],
            dtype=np.float32)
        if center[0] != -1:
            scale = scale * 1.25

        return center, scale

    def compute_scale(self, joints):
        box = [min(joints[:, 0]), min(joints[:, 1]), max(joints[:, 0]), max(joints[:, 1])]
        center, scale = self._box2cs(box)
        return scale

    def _generate_target(self, joints, heatmap_size, heatmap_sigma):
        num_joints = joints.shape[0]
        target_weight = np.ones((num_joints, 1), dtype=np.float32)
        target_weight[:, 0] = 1

        target = np.zeros((num_joints, heatmap_size[1], heatmap_size[0]), dtype=np.float32)

        tmp_size = heatmap_sigma * 3

        for joint_id in range(num_joints):
            feat_stride = np.asarray(self.image_size) / np.asarray(heatmap_size)

            mu_x = int(joints[joint_id, 0] / feat_stride[0] + 0.5)
            mu_y = int(joints[joint_id, 1] / feat_stride[1] + 0.5)

            ul = [int(mu_x - tmp_size), int(mu_y - tmp_size)]
            br = [int(mu_x + tmp_size + 1), int(mu_y + tmp_size + 1)]

            size = 2 * tmp_size + 1
            x = np.arange(0, size, 1, np.float32)
            y = x[:, np.newaxis]
            x0 = y0 = size // 2
            g = np.exp(-((x - x0) ** 2 + (y - y0) ** 2) / (2 * heatmap_sigma ** 2))

            g_x = max(0, -ul[0]), min(br[0], heatmap_size[0]) - ul[0]
            g_y = max(0, -ul[1]), min(br[1], heatmap_size[1]) - ul[1]

            img_x = max(0, ul[0]), min(br[0], heatmap_size[0])
            img_y = max(0, ul[1]), min(br[1], heatmap_size[1])

            target[joint_id, img_y[0]:img_y[1], img_x[0]:img_x[1]] = g[g_y[0]:g_y[1], g_x[0]:g_x[1]]

        return target, target_weight

    def __getitem__(self, idx):

        img_path = os.path.join(self.data_dir, "image", f"{idx + 1}.png")
        try:
            image = cv2.imread(img_path)
            if image is None:
                print(f"Unable to load image: {img_path}")
                image = np.zeros((self.image_size[1], self.image_size[0], 3), dtype=np.uint8)
            else:
                if image.ndim == 2:
                    image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        except Exception as e:
            print(f"Error loading image: {e}, Image path: {img_path}")
            image = np.zeros((self.image_size[1], self.image_size[0], 3), dtype=np.uint8)

        pose = np.array(self.poses[idx], dtype=np.float32)

        # 在这之后继续进行数据处理，包括数据增强、目标生成等（数据增强我删掉了）
        ###########################################################################

        # 首先48和64传入是对的
        pose[:, 0], pose[:, 1] = pose[:, 1], pose[:, 0].copy()

        image = self.transform(image)
        target, target_weight = self._generate_target(pose, (48, 64), 3)
        # print(image.shape)
        return image, torch.from_numpy(target), torch.from_numpy(target_weight)


# 两个数据合并起来的dataloader
import torch
# 创建数据读取器
from torchvision import transforms
from torch.utils.data import DataLoader
import torch.optim as optim
# from model import *
from torchvision import datasets
import torchvision.transforms as transforms
from torch.utils.data import ConcatDataset
from torchvision.datasets.folder import default_loader
from PIL import Image


def default_loader(path):
    try:
        img = Image.open(path).convert('RGB')
        if img is None:
            print(f"Unable to load image: {path}")
            return Image.new("RGB", (400, 712), "white")  # 返回一个白色的默认图像
        if img.mode == 'L':
            img = img.convert('RGB')
        return img
    except Image.UnidentifiedImageError as e:
        print(f"Error loading image: {e}, Image path: {path}")
        return Image.new("RGB", (400, 712), "white")  # 返回一个白色的默认图像


# 注意图片格式需要用png,到时候修改一下就行
def lowlight_dataset(data_path):
    extensions = ['.png']  # 指定图片扩展名，可以根据实际情况调整
    train_dataset = datasets.DatasetFolder(
        root=data_path,
        loader=default_loader,
        extensions=extensions,
        transform=transforms.ToTensor()
    )
    return train_dataset


class MyDataset(torch.utils.data.Dataset):
    def __init__(self, file_path):
        self.file_path = file_path
        self.coco_dataset = CustomDataset(data_dir=file_path)  # 初始化你的COCO数据集
        self.lowlight_dataset = lowlight_dataset(self.file_path)

    def __len__(self):
        # 这里根据文件路径加载数据集的长度
        data = lowlight_dataset(self.file_path)
        return len(data)

    def __getitem__(self, index):  # !!!代表着索引获取数据 ,但是现在发现一个问题，索引值不一样，明明都是五张图片
        # 这里根据文件路径加载数据
        images, targets, weights = self.coco_dataset[index][:3]  # 假设COCODataset提供了按索引获取数据的方法
        resize_transform = transforms.Resize((256, 192))
        images = resize_transform(images)

        lowlight_data = self.lowlight_dataset[index]

        # 在这里处理 lowlight_data，获取你需要的数据
        return images, targets, weights, lowlight_data


# 训练部分
dataset = MyDataset(r"/mnt/data2/temp2/pycharm_project_887/sample_data/")
train_loader = DataLoader(dataset, batch_size=6, shuffle=True, num_workers=2, pin_memory=True, drop_last=True)


def train(pose_network, lowlight_network):
    for epoch in tqdm(range(100)):

        for batch in train_loader:
            images, targets, weights, lowlight_data = batch
            # print(images.shape)
            images = images.to(device).float()
            targets = targets.to(device).float()
            weights = weights.to(device).float()
            data_low = lowlight_data[0].to(device).float()

            output2, fmap = lowlight_network(data_low)
            fmap = fmap.to(device).float()

            output1 = pose_network(images, fmap)

            selected_indices = [0, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 22]

            output1 = output1[:, selected_indices, :, :]

            pose_loss = pose_criterion(output1, targets, weights)

            # 反向传播和优化
            pose_optimizer.zero_grad()
            pose_loss.backward()
            pose_optimizer.step()

        print(f"Epoch {epoch + 1}, Total Epoch Loss: {pose_loss}")

        if (epoch + 1) % 10 == 0:
            pose_state = pose_network.state_dict()
            # pose_opt_state = pose_optimizer.state_dict()
            pose_path = f'(3)fine_epoch_{epoch + 1}_pose.pth'
            torch.save({'state_dict': pose_state}, pose_path)


train(pose_network, lowlight_network)